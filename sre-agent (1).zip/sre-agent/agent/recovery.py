"""Step 6b - VERIFY recovery after an approved action; roll back + escalate if it did not recover.

Recovered = for 2 consecutive polls, none of the alert rules fire for the root-cause service or the
services that were symptomatic in the alert (their error rate / p95 / traffic back near baseline and the
container running). Waits up to VERIFY_SECONDS.
"""
import time

from agent import config, detect


def _relevant(ev: dict, watch: set) -> list:
    return [r for r in ev["reasons"] if any(r.startswith(s + " ") or f" {s} " in r for s in watch)]


def verify(watch_services: list, before: dict = None, log=print, snapshot=None,
           seconds: int = None, poll: int = None) -> dict:
    snapshot = snapshot or (lambda: detect.snapshot(config.VERIFY_WINDOW))
    seconds = config.VERIFY_SECONDS if seconds is None else seconds
    poll = config.VERIFY_POLL if poll is None else poll
    watch = set(watch_services)
    timeline, good = [], 0
    t0 = time.time()
    if poll:
        time.sleep(poll)  # give span metrics time to reflect the change
    while True:
        snap = snapshot()
        bad = _relevant(snap["eval"], watch)
        row = {"t_plus_s": round(time.time() - t0), "still_failing": bad,
               "metrics": {s: snap["health"].get(s) for s in watch if snap["health"].get(s)}}
        timeline.append(row)
        log(f"  verify t+{row['t_plus_s']}s: " + ("healthy" if not bad else "; ".join(bad[:3])))
        good = good + 1 if not bad and not snap["errors"] else 0
        if good >= 2:
            return {"recovered": True, "after_seconds": row["t_plus_s"], "timeline": timeline,
                    "before": before, "after": row["metrics"]}
        if time.time() - t0 >= seconds:
            return {"recovered": False, "after_seconds": row["t_plus_s"], "timeline": timeline,
                    "before": before, "after": row["metrics"], "still_failing": bad}
        time.sleep(poll)
