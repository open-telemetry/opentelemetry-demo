"""Tiny test runner (no pytest needed): python -m tests.run"""
import sys
import traceback

from tests import test_agent

fails = 0
names = [n for n in dir(test_agent) if n.startswith("test_")]
for n in names:
    try:
        getattr(test_agent, n)()
        print(f"  PASS {n}")
    except Exception:
        fails += 1
        print(f"  FAIL {n}")
        traceback.print_exc(limit=3)
print(f"\n{len(names) - fails}/{len(names)} passed")
sys.exit(1 if fails else 0)
